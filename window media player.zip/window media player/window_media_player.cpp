#include <iostream>
#include <fstream>
#include <Windows.h>
using namespace std;

int sizeofarray(const char arr[])
{
	int ct = 0;
	for (int i = 0; arr[i] != '\0'; i++)
	{
		ct++;
	}
	return ct;
}

class dnode {
public:
	char* title;
	dnode* next, *prev;

	dnode()
	{
		title = nullptr;
		next = prev = nullptr;
	}

	dnode(const char title[])
	{
		int len = sizeofarray(title);
		this->title = new char[len + 1];
		for (int i = 0; i < len; i++)
		{
			this->title[i] = title[i];
		}
		this->title[len] = '\0';
		next = prev = nullptr;
	}

	~dnode()
	{
		delete[] title;
	}
};

class dlist {
public:
	dnode* head, *tail, *currentSong;

	dlist()
	{
		head = tail = currentSong = nullptr;
	}

	void addSong(const char title[])
	{
		dnode* temp = new dnode(title);

		if (head == nullptr)
		{
			head = temp;
			tail = temp;
		}
		else
		{
			tail->next = temp;
			temp->prev = tail;
			tail = temp;
		}
	}

	void displaySongForward()
	{
		dnode* curr = head;
		if (head == nullptr)
		{
			cout << "No Songs Are Selected" << endl;
		}
		else
		{
			cout << "Songs List is Given below :\n" << endl;
			while (curr != nullptr)
			{
				cout << curr->title << endl;
				curr = curr->next;
			}
			cout << endl;
		}
	}

	void displaySongBackward()
	{
		dnode* curr = tail;
		if (tail == nullptr)
		{
			cout << "No Songs Are Selected" << endl;
		}
		else
		{
			while (curr != nullptr)
			{
				cout << curr->title << endl;
				curr = curr->prev;
			}
			cout << endl;
		}
	}

	~dlist()
	{
		dnode* curr = head;
		while (curr != nullptr)
		{
			dnode* nextNode = curr->next;
			delete curr;
			curr = nextNode;
		}
		head = tail = currentSong = nullptr;
	}
};

void loadPlaylist(dlist& obj)
{
	ifstream fin;
	fin.open("SongFile.txt");

	if (!fin.is_open())
	{
		cout << "File for songs is not found" << endl;
	}
	else {
		char arr[50];

		while (!fin.eof())
		{
			fin.getline(arr, 50);
			obj.addSong(arr);
		}

		obj.currentSong = obj.head; // Set the current song to the first song
		fin.close();
	}
}

void playSong(dlist& obj) {
	if (obj.currentSong != nullptr)
	{
		cout << "Now playing: " << obj.currentSong->title << "\n" << endl;
		PlaySound(TEXT(obj.currentSong->title), NULL, SND_ASYNC);
	}
	else
	{
		cout << "No song selected." << endl;
	}
}

void stopCurrentSong()
{
	PlaySound(NULL, NULL, 0);  // Stop the currently playing sound
}

void nextSong(dlist& obj)
{
	if (obj.currentSong != nullptr)
	{
		if (obj.currentSong->next != nullptr)
		{
			obj.currentSong = obj.currentSong->next;
		}
		else
		{
			obj.currentSong = obj.head; // Wrap around to the first song
		}
		stopCurrentSong();  // Stop the current song before playing the next one
		playSong(obj);
	}
	else
	{
		cout << "No next song available." << endl;
	}
}

void previousSong(dlist& obj)
{
	if (obj.currentSong != nullptr)
	{
		if (obj.currentSong->prev != nullptr)
		{
			obj.currentSong = obj.currentSong->prev;
		}
		else
		{
			obj.currentSong = obj.tail; // Wrap around to the last song
		}
		stopCurrentSong();  // Stop the current song before playing the previous one
		playSong(obj);
	}
	else
	{
		cout << "No previous song available." << endl;
	}
}

void playRandomSong(dlist& obj)
{
	if (obj.head != nullptr)
	{
		int numSongs = 0;
		dnode* temp = obj.head;
		while (temp != nullptr)
		{
			numSongs++;
			temp = temp->next;
		}

		int randomIndex = rand() % numSongs; //Generate a random index using rand and song played using that index 
		dnode* randomSong = obj.head;
		for (int i = 0; i < randomIndex; i++)
		{
			if (randomSong->next != nullptr)
			{
				randomSong = randomSong->next;
			}
			else
			{
				randomSong = obj.head; // Wrap around to the first song
			}
		}

		obj.currentSong = randomSong;
		stopCurrentSong();
		playSong(obj);
	}
	else
	{
		cout << "No songs available to play randomly." << endl;
	}
}

int main() {
	dlist obj;

	loadPlaylist(obj);
	obj.displaySongForward();

	char choice = '\0';
	do {
		cout << "Press P for Playing Songs" << endl;
		cout << "Press N for Next song " << endl;
		cout << "Press B for Previous song" << endl;
		cout << "Press S to stop the current song" << endl;
		cout << "Press R for playing a random song" << endl; // Add this line for the random song option
		cout << "Press E for Exit" << endl;

		cin >> choice;
		if (choice == 'P' || choice == 'p')
		{
			playSong(obj);
		}
		else if (choice == 'N' || choice == 'n')
		{
			nextSong(obj);
		}
		else if (choice == 'B' || choice == 'b')
		{
			previousSong(obj);
		}
		else if (choice == 'S' || choice == 's')
		{
			stopCurrentSong();
		}
		else if (choice == 'R' || choice == 'r')  
		{
			playRandomSong(obj);
		}
		else if (choice == 'E' || choice == 'e')
		{
			cout << "Songs Closed Successfully" << endl;
			break;
		}
		else
		{
			cout << "\nPress only Given Choices..\n" << endl;
		}

	} while (choice != 'E');

	system("pause");
	return 0;
}
